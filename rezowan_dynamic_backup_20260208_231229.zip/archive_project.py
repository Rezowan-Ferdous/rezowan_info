
import shutil
import os
import datetime

def make_archive():
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_name = f"rezowan_dynamic_backup_{timestamp}"
    root_dir = os.getcwd()
    
    # Create a list of files/dirs to include (excluding huge venv/node_modules if any)
    # For simplicity, we'll use shutil.make_archive but need to be careful not to include the archive itself or venv
    
    # Better approach: Copy relevant files to a temp folder then zip
    build_dir = os.path.join(root_dir, "temp_archive_build")
    if os.path.exists(build_dir):
        shutil.rmtree(build_dir)
    os.makedirs(build_dir)
    
    target_items = ['app', 'run.py', 'requirements.txt', 'create_db.py', 'create_admin.py', 'README.md', '.env', 'instance']
    
    print(f"Archiving to {archive_name}.zip...")
    
    for item in os.listdir(root_dir):
        if item in target_items or item.endswith('.py') or item.endswith('.md'):
            s = os.path.join(root_dir, item)
            d = os.path.join(build_dir, item)
            if os.path.isdir(s):
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)
                
    shutil.make_archive(archive_name, 'zip', build_dir)
    shutil.rmtree(build_dir)
    print("Archive created.")

if __name__ == "__main__":
    make_archive()
