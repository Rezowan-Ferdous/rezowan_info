from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from os import path

db = SQLAlchemy()
DB_NAME = "database.db"

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'dev_secret_key_change_in_prod'
    # Use PostgreSQL database
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:Rez.7890@localhost/rezowan_info'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)

    from flask_login import LoginManager
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        from .models import User
        return User.query.get(int(user_id))

    from flask_ckeditor import CKEditor
    ckeditor = CKEditor(app)
    app.config['CKEDITOR_FILE_UPLOADER'] = 'admin.upload'
    app.config['CKEDITOR_ENABLE_CSRF'] = True

    from .routes import views
    from .auth import auth
    from .admin import admin

    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/')
    app.register_blueprint(admin, url_prefix='/admin')

    from .models import Experience, Publication, Project, Interest
    
    with app.app_context():
        db.create_all()
        # Check if empty, if so seed (simple check)
        if not Experience.query.first():
            from .seed_data import seed_database
            seed_database(db)

    return app
