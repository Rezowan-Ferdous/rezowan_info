from flask import Blueprint, render_template
from .models import Experience, Publication, Project, Interest, BlogPost

views = Blueprint('views', __name__)

@views.route('/')
def home():
    # Fetch highlights for the home page
    featured_projects = Project.query.limit(3).all()
    latest_publications = Publication.query.order_by(Publication.year.desc()).limit(3).all()
    return render_template("home.html", projects=featured_projects, publications=latest_publications)

@views.route('/research')
def research():
    publications = Publication.query.order_by(Publication.year.desc()).all()
    journals = [p for p in publications if p.pub_type == 'Journal']
    conferences = [p for p in publications if p.pub_type == 'Conference']
    return render_template("research.html", journals=journals, conferences=conferences)

@views.route('/projects')
def projects():
    all_projects = Project.query.all()
    return render_template("projects.html", projects=all_projects)

@views.route('/experience')
def experience():
    experiences = Experience.query.order_by(Experience.start_date.desc()).all()
    return render_template("experience.html", experiences=experiences)

@views.route('/blog')
def blog_index():
    posts = BlogPost.query.order_by(BlogPost.date_posted.desc()).all()
    return render_template("blog/index.html", posts=posts)

@views.route('/blog/<slug>')
def post_detail(slug):
    post = BlogPost.query.filter_by(slug=slug).first_or_404()
    return render_template("blog/post.html", post=post)
