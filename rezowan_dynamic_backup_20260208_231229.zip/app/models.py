from . import db
from datetime import datetime

class Experience(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    position = db.Column(db.String(100), nullable=False)
    company = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100))
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True) # Null for 'Present'
    description = db.Column(db.Text)
    
    def to_dict(self):
        return {
            'id': self.id,
            'position': self.position,
            'company': self.company,
            'location': self.location,
            'start_date': self.start_date.strftime('%b %Y'),
            'end_date': self.end_date.strftime('%b %Y') if self.end_date else 'Present',
            'description': self.description
        }

class Publication(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    authors = db.Column(db.String(255), nullable=False)
    venue = db.Column(db.String(150), nullable=False) # e.g. "IEEE HRI"
    year = db.Column(db.Integer, nullable=False)
    link = db.Column(db.String(255))
    pub_type = db.Column(db.String(50)) # 'Journal', 'Conference', 'Workshop'
    impact_factor = db.Column(db.String(50)) # Optional, e.g. "Q1", "Impact Factor 5.0"

class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    technologies = db.Column(db.String(200)) # Comma separated tags
    image_url = db.Column(db.String(255))
    project_url = db.Column(db.String(255))
    github_url = db.Column(db.String(255))
    category = db.Column(db.String(50)) # e.g., 'Robotics', 'Computer Vision'

class Interest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    topic = db.Column(db.String(100), nullable=False)
    icon = db.Column(db.String(50)) # FontAwesome class or similar
    details = db.Column(db.Text)

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class BlogPost(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), unique=True, nullable=False)
    content = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'slug': self.slug,
            'content': self.content,
            'date_posted': self.date_posted.strftime('%Y-%m-%d')
        }
