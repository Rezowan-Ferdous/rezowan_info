from datetime import datetime
from .models import Experience, Publication, Project, Interest
from .pdf_extractor import extract_content_from_pdf

def seed_database(db):
    pdf_path = "C:/Users/rezow/Downloads/Academic_CV_Template.pdf"
    print(f"Seeding database from {pdf_path}...")
    
    data = extract_content_from_pdf(pdf_path)
    if not data:
        print("No data extracted from PDF.")
        return

    # Clear existing data
    db.session.query(Experience).delete()
    db.session.query(Publication).delete()
    db.session.query(Project).delete()
    db.session.query(Interest).delete()
    db.session.commit()
    print("Cleared existing data.")

    # Insert Experience
    for item in data.get("experience", []):
        try:
            start_date = datetime.strptime(item.get("start_date", "2023-01-01"), "%Y-%m-%d").date()
        except:
            start_date = datetime(2023, 1, 1).date()
            
        exp = Experience(
            position=item.get("position", "Researcher"),
            company=item.get("company", "Unknown Company"),
            location=item.get("location", "Unknown"),
            start_date=start_date,
            end_date=None,
            description=item.get("description", "")
        )
        db.session.add(exp)

    # Insert Projects
    for item in data.get("projects", []):
        proj = Project(
            title=item.get("title", "Untitled Project"),
            description=item.get("description", ""),
            technologies=item.get("technologies", "Python"),
            category=item.get("category", "General")
        )
        db.session.add(proj)

    # Insert Publications
    for item in data.get("publications", []):
        pub = Publication(
            title=item.get("title", "Untitled Publication"),
            authors=item.get("authors", "Rezowan et al."),
            venue=item.get("venue", "Conference"),
            year=item.get("year", 2024),
            link=item.get("link", "#"),
            pub_type=item.get("pub_type", "Conference"),
            impact_factor=item.get("impact_factor", "")
        )
        db.session.add(pub)

    # Insert Interests
    for item in data.get("interests", []):
        interest = Interest(
            topic=item.get("topic", "General Interest"),
            details=item.get("details", ""),
            icon=item.get("icon", "fa-star")
        )
        db.session.add(interest)

    db.session.commit()
    print("Database seeded successfully!")
