
import pdfplumber
import re
import os

def extract_content_from_pdf(pdf_path):
    if not os.path.exists(pdf_path):
        print(f"PDF not found at {pdf_path}")
        return {}

    full_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            width = page.width
            words = page.extract_words()
            
            # Simple column detection: Check if there's a density gap in the middle
            # CVs usually read: Left Column (Contact/Skills) -> Right Column (Exp/Edu) or vice versa
            # We'll just append them.
            
            left_words = []
            right_words = []
            
            split_x = width * 0.35
            
            for word in words:
                if word['x0'] < split_x:
                    left_words.append(word)
                else:
                    right_words.append(word)
            
            # Function to reconstruct text from words
            def words_to_text(word_list):
                 # Group by line
                lines = {}
                for word in word_list:
                    top = round(word['top'] / 5) * 5 
                    if top not in lines:
                        lines[top] = []
                    lines[top].append(word)
                
                text_block = ""
                sorted_tops = sorted(lines.keys())
                for top in sorted_tops:
                    line_words = sorted(lines[top], key=lambda w: w['x0'])
                    line_text = " ".join([w['text'] for w in line_words])
                    text_block += line_text + "\n"
                return text_block

            full_text += words_to_text(left_words) + "\n" + words_to_text(right_words) + "\n"
            
    # Now parse the structured text
    data = {
        "experience": [],
        "publications": [],
        "projects": [],
        "interests": []
    }
    
    # Heuristic Parsing
    lines = full_text.split('\n')
    
    current_section = None
    
    for line in lines:
        line = line.strip()
        if not line: continue
        
        # Detect Section Headers
        if re.match(r'^(EXPERIENCE|WORK EXPERIENCE|EMPLOYMENT)$', line, re.IGNORECASE):
            current_section = "experience"
            continue
        elif re.match(r'^(PUBLICATIONS|SELECTED PUBLICATIONS)$', line, re.IGNORECASE):
            current_section = "publications"
            continue
        elif re.match(r'^(PROJECTS|ACADEMIC PROJECTS)$', line, re.IGNORECASE):
            current_section = "projects"
            continue
        elif re.search(r'INTERESTS', line, re.IGNORECASE):
            current_section = "interests"
            continue

        # Parse content based on section
        if current_section == "experience":
            # Heuristic: line with date or company
            if len(line) > 10 and not line.lower().startswith('description'):
                data["experience"].append({
                     "position": "Researcher/Developer", # Placeholder
                     "company": line,
                     "location": "Unknown",
                     "start_date": "2023-01-01",
                     "end_date": None,
                     "description": line
                })
        elif current_section == "publications":
            if len(line) > 20:
                 data["publications"].append({
                     "title": line,
                     "authors": "Rezowan et al.",
                     "venue": "Conference",
                     "year": 2024,
                     "link": "#",
                     "pub_type": "Conference",
                     "impact_factor": "Q1"
                 })
        elif current_section == "projects":
             if len(line) > 10:
                  data["projects"].append({
                        "title": line.split(':')[0] if ':' in line else line[:20],
                        "description": line,
                        "technologies": "Python, AI",
                        "category": "Project"
                  })
        elif current_section == "interests":
             data["interests"].append({
                 "topic": line,
                 "details": "",
                 "icon": "fa-star"
             })

    return data
