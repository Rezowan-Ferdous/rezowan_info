
from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from .models import Project, Experience, Publication, BlogPost, Interest
from . import db
from datetime import datetime

admin = Blueprint('admin', __name__, url_prefix='/admin')

@admin.route('/')
@login_required
def dashboard():
    projects = Project.query.all()
    experiences = Experience.query.all()
    publications = Publication.query.all()
    posts = BlogPost.query.all()
    return render_template("admin/dashboard.html", user=current_user, 
                           projects=projects, experiences=experiences, 
                           publications=publications, posts=posts)

# --- Blog Post CRUD ---
@admin.route('/post/new', methods=['GET', 'POST'])
@login_required
def new_post():
    if request.method == 'POST':
        title = request.form.get('title')
        slug = request.form.get('slug')
        content = request.form.get('content')

        if not title or not content:
            flash('Title and Content are required!', category='error')
        else:
            new_post = BlogPost(title=title, slug=slug, content=content)
            db.session.add(new_post)
            db.session.commit()
            flash('Post created!', category='success')
            return redirect(url_for('admin.dashboard'))

    return render_template("admin/edit_post.html", user=current_user, post=None)

@admin.route('/post/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_post(id):
    post = BlogPost.query.get_or_404(id)
    if request.method == 'POST':
        post.title = request.form.get('title')
        post.slug = request.form.get('slug')
        post.content = request.form.get('content')
        
        db.session.commit()
        flash('Post updated!', category='success')
        return redirect(url_for('admin.dashboard'))

    return render_template("admin/edit_post.html", user=current_user, post=post)

@admin.route('/post/delete/<int:id>')
@login_required
def delete_post(id):
    post = BlogPost.query.get_or_404(id)
    db.session.delete(post)
    db.session.commit()
    flash('Post deleted!', category='success')
    return redirect(url_for('admin.dashboard'))

from flask_ckeditor import upload_success, upload_fail
import os

@admin.route('/upload', methods=['POST'])
@login_required
def upload():
    f = request.files.get('upload')
    extension = f.filename.split('.')[-1].lower()
    if extension not in ['jpg', 'gif', 'png', 'jpeg']:
        return upload_fail(message='Image only!')
    
    # Save file
    filename = f.filename
    # Ensure directory exists
    upload_dir = os.path.join(os.getcwd(), 'app/static/uploads')
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)

    upload_path = os.path.join(upload_dir, filename)
    f.save(upload_path)
    
    url = url_for('static', filename=f'uploads/{filename}')
    return upload_success(url, filename=filename)

# --- Project CRUD ---
@admin.route('/project/new', methods=['GET', 'POST'])
@login_required
def new_project():
    if request.method == 'POST':
        proj = Project(
            title=request.form.get('title'),
            description=request.form.get('description'),
            technologies=request.form.get('technologies'),
            category=request.form.get('category'),
            github_url=request.form.get('github_url')
        )
        db.session.add(proj)
        db.session.commit()
        flash('Project created!', category='success')
        return redirect(url_for('admin.dashboard'))
    return render_template("admin/edit_project.html", project=None)

@admin.route('/project/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_project(id):
    proj = Project.query.get_or_404(id)
    if request.method == 'POST':
        proj.title = request.form.get('title')
        proj.description = request.form.get('description')
        proj.technologies = request.form.get('technologies')
        proj.category = request.form.get('category')
        proj.github_url = request.form.get('github_url')
        db.session.commit()
        flash('Project updated!', category='success')
        return redirect(url_for('admin.dashboard'))
    return render_template("admin/edit_project.html", project=proj)

@admin.route('/project/delete/<int:id>')
@login_required
def delete_project(id):
    proj = Project.query.get_or_404(id)
    db.session.delete(proj)
    db.session.commit()
    flash('Project deleted!', category='success')
    return redirect(url_for('admin.dashboard'))

# --- Publication CRUD ---
@admin.route('/publication/new', methods=['GET', 'POST'])
@login_required
def new_publication():
    if request.method == 'POST':
        pub = Publication(
            title=request.form.get('title'),
            authors=request.form.get('authors'),
            venue=request.form.get('venue'),
            year=int(request.form.get('year')),
            pub_type=request.form.get('pub_type'),
            link=request.form.get('link')
        )
        db.session.add(pub)
        db.session.commit()
        flash('Publication created!', category='success')
        return redirect(url_for('admin.dashboard'))
    return render_template("admin/edit_publication.html", publication=None)

@admin.route('/publication/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_publication(id):
    pub = Publication.query.get_or_404(id)
    if request.method == 'POST':
        pub.title = request.form.get('title')
        pub.authors = request.form.get('authors')
        pub.venue = request.form.get('venue')
        pub.year = int(request.form.get('year'))
        pub.pub_type = request.form.get('pub_type')
        pub.link = request.form.get('link')
        db.session.commit()
        flash('Publication updated!', category='success')
        return redirect(url_for('admin.dashboard'))
    return render_template("admin/edit_publication.html", publication=pub)

@admin.route('/publication/delete/<int:id>')
@login_required
def delete_publication(id):
    pub = Publication.query.get_or_404(id)
    db.session.delete(pub)
    db.session.commit()
    flash('Publication deleted!', category='success')
    return redirect(url_for('admin.dashboard'))

# --- Experience CRUD ---
@admin.route('/experience/new', methods=['GET', 'POST'])
@login_required
def new_experience():
    if request.method == 'POST':
        start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
        end_date_str = request.form.get('end_date')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str else None
        
        exp = Experience(
            position=request.form.get('position'),
            company=request.form.get('company'),
            location=request.form.get('location'),
            start_date=start_date,
            end_date=end_date,
            description=request.form.get('description')
        )
        db.session.add(exp)
        db.session.commit()
        flash('Experience created!', category='success')
        return redirect(url_for('admin.dashboard'))
    return render_template("admin/edit_experience.html", experience=None)

@admin.route('/experience/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_experience(id):
    exp = Experience.query.get_or_404(id)
    if request.method == 'POST':
        exp.position = request.form.get('position')
        exp.company = request.form.get('company')
        exp.location = request.form.get('location')
        exp.start_date = datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date()
        end_date_str = request.form.get('end_date')
        exp.end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str else None
        exp.description = request.form.get('description')
        
        db.session.commit()
        flash('Experience updated!', category='success')
        return redirect(url_for('admin.dashboard'))
    return render_template("admin/edit_experience.html", experience=exp)

@admin.route('/experience/delete/<int:id>')
@login_required
def delete_experience(id):
    exp = Experience.query.get_or_404(id)
    db.session.delete(exp)
    db.session.commit()
    flash('Experience deleted!', category='success')
    return redirect(url_for('admin.dashboard'))

# Use simplified approach for other items for now (user requested "upload stuff")
# We can expand if needed.
