# Rezowan - AI Researcher Portfolio

A professional portfolio website built with Flask, SQLAlchemy, and Docker. Designed for Computer Vision and Robotics researchers.

## Features
- **Dynamic Content**: Manage Experience, Publications, Projects, and Interests via Database.
- **Research Focused**: Dedicated section for Journal (Q1) and Conference (Rank A) papers.
- **Modern Design**: Responsive, dark/light theme, glassmorphism UI.
- **Dockerized**: Ready for deployment on AWS, DigitalOcean, etc.

## Setup

### Local Development
1. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python run.py
   ```
   Access at `http://localhost:5000`.

### Docker Deployment
1. Build and run:
   ```bash
   docker-compose up --build
   ```
   Access at `http://localhost:5000`.

## Deployment to AWS (Elastic Beanstalk or EC2)
1. Ensure `gunicorn` is in `requirements.txt`.
2. **EC2**: Clone repo, install Docker, run `docker-compose up -d`.
3. **Elastic Beanstalk**: Zip the project (excluding venv) and deploy as a Python application.

## Database
The app uses SQLite (`database.db`) by default for simplicity. To switch to MySQL, update `SQLALCHEMY_DATABASE_URI` in `app/__init__.py`.
