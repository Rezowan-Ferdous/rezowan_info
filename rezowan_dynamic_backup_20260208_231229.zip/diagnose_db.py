
import psycopg2
from sqlalchemy import create_engine, inspect

def diagnose_db():
    print("Diagnosis starting...")
    
    # 1. Check raw connection and tables via psycopg2
    try:
        conn = psycopg2.connect(
            host="localhost",
            user="postgres",
            password="Rez.7890",
            database="rezowan_info"
        )
        cur = conn.cursor()
        cur.execute("""
            SELECT table_schema, table_name
            FROM information_schema.tables
            WHERE table_schema != 'pg_catalog'
            AND table_schema != 'information_schema'
        """)
        tables = cur.fetchall()
        print("\n[Psycopg2] Tables found in 'rezowan_info':")
        for schema, table in tables:
            print(f" - {schema}.{table}")
        
        # Check row counts if tables exist
        for schema, table in tables:
            cur.execute(f"SELECT COUNT(*) FROM {schema}.{table}")
            count = cur.fetchone()[0]
            print(f"   -> Rows: {count}")

        cur.close()
        conn.close()
    except Exception as e:
        print(f"\n[Psycopg2] Connection failed: {e}")

    # 2. Check via SQLAlchemy (as used in app)
    try:
        uri = 'postgresql://postgres:Rez.7890@localhost/rezowan_info'
        engine = create_engine(uri)
        inspector = inspect(engine)
        print(f"\n[SQLAlchemy] Tables found using URI '{uri}':")
        for table_name in inspector.get_table_names():
            print(f" - {table_name}")
            
    except Exception as e:
        print(f"\n[SQLAlchemy] Connection failed: {e}")

if __name__ == "__main__":
    diagnose_db()
