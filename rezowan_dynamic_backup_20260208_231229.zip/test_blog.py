
from app import create_app, db
from app.models import BlogPost

app = create_app()
with app.app_context():
    print("Creating test blog post...")
    post = BlogPost(
        title="Welcome to my new Blog",
        slug="welcome-blog",
        content="<p>This is the first post on my new blog system!</p>"
    )
    db.session.add(post)
    db.session.commit()
    print("Blog post created successfully.")

    # Verify
    count = BlogPost.query.count()
    print(f"Total blog posts: {count}")
    
    fetched_post = BlogPost.query.filter_by(slug="welcome-blog").first()
    if fetched_post:
        print(f"Verified post: {fetched_post.title}")
    else:
        print("Failed to verify post.")
