
from app.pdf_extractor import extract_content_from_pdf
import pdfplumber

# Copy of function to just return text for debugging
def get_pdf_text(pdf_path):
    full_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            width = page.width
            words = page.extract_words()
            left_words = []
            right_words = []
            split_x = width * 0.35
            for word in words:
                if word['x0'] < split_x:
                    left_words.append(word)
                else:
                    right_words.append(word)
            
            def words_to_text(word_list):
                lines = {}
                for word in word_list:
                    top = round(word['top'] / 5) * 5 
                    if top not in lines:
                        lines[top] = []
                    lines[top].append(word)
                text_block = ""
                sorted_tops = sorted(lines.keys())
                for top in sorted_tops:
                    line_words = sorted(lines[top], key=lambda w: w['x0'])
                    line_text = " ".join([w['text'] for w in line_words])
                    text_block += line_text + "\n"
                return text_block

            full_text += words_to_text(left_words) + "\n" + words_to_text(right_words) + "\n"
    return full_text

if __name__ == "__main__":
    pdf_path = "C:/Users/rezow/Downloads/Academic_CV_Template.pdf"
    print(get_pdf_text(pdf_path))
